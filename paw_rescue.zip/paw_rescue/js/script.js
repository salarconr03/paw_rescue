document.addEventListener("DOMContentLoaded", () => {
  console.log("Página cargada correctamente ");
});
